# Jigsaw puzzle

A Pen created on CodePen.

Original URL: [https://codepen.io/Dillo/pen/QWKLYab](https://codepen.io/Dillo/pen/QWKLYab).

Edit January 23, 2021 : randomized initial z-index of pieces. Before this, the bottom-line pieces were always on the top.  
Edit May 28, 2021 : improved shape of pieces.  
Edit September 29,2021 : compatible with touch screen devices. Hopefully, since I have no such device to make tests.  
Edit December 28, 2021 : fixed bug with unexpected mouse down events + FF not clipping drawings if shadow is defined.  
Edit June 17,2024 : added resizing + choice of shape of pieces